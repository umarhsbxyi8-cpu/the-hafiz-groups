/* Website content: all text, products, categories and image paths.
   Images live in the "images" folder. */
window.SITE_DATA = {
  "co": {
    "name": "HAFIZ BUILDING MATERIAL COMPANY",
    "heroT": "Quality Building Materials, Delivered",
    "heroS": "Sandwich panels, roofing sheets, steel pipes & sections and fencing - everything for your construction project from one trusted supplier.",
    "prodSub": "Browse our range. Tap Enquire to request a quotation.",
    "about": "Hafiz Building Material Company is a trusted supplier of quality construction materials for builders, contractors, traders and homeowners. We specialise in PU sandwich panels, roofing and cladding sheets, steel pipes, tubes and sections, and temporary fencing panels.\n\nWe understand that every project depends on reliable materials and timely supply. That is why we offer a wide range of products, honest advice on choosing the right material, and quick quotations for both wholesale and retail orders.\n\nFrom small repairs to large construction projects, our team is committed to quality, fair dealing and customer satisfaction.",
    "mission": "To supply dependable, good-quality building materials at fair prices, and to be the first choice of builders and contractors through honest service, timely delivery and long-term relationships.",
    "why": "Wide range of building materials in one place\nQuality-checked products\nWholesale and retail supply\nQuick response and fast quotations\nHelpful advice for choosing the right material\nSupport for your project from start to finish",
    "phone": "+971 50 984 2497",
    "hrs": "",
    "whT": "Bulk supply for contractors, traders and projects at competitive rates, with timely delivery and quotations on request.",
    "rtT": "Buy the quantity you need. Roofing sheets, panels, pipes and sections available for individual customers.",
    "wa": "971509842497",
    "email": "",
    "addr": "",
    "logo": "images/logo.png",
    "ceo": "images/ceo-photo.jpg",
    "ceoT": "Our CEO leads a group of building materials companies, including Silver Metal Industries LLC SP, Jabrul Haq Building Materials LLC, Muhammad Yar Bldg Mat Tr and Al-Fath Building Materials Trading LLC SP.\n\nWith a clear focus on quality, honest dealing and customer satisfaction, he guides the group in supplying PU sandwich panels, roofing and cladding sheets, steel pipes, tubes and sections, and temporary fencing to builders, contractors and traders.\n\nUnder his leadership, every company in the group is committed to dependable materials, fair prices and long-term relationships with its customers.",
    "qr": "images/whatsapp-qr.png",
    "fb": "",
    "ig": "",
    "tt": "",
    "yt": "",
    "soc": [
      {
        "n": "Facebook",
        "qr": "",
        "url": ""
      },
      {
        "n": "Instagram",
        "qr": "images/social/instagram-qr.png",
        "url": "https://www.instagram.com/hafizgroups.com.5"
      },
      {
        "n": "TikTok",
        "qr": "images/social/tiktok-qr.png",
        "url": ""
      },
      {
        "n": "YouTube",
        "qr": "",
        "url": ""
      },
      {
        "n": "X (Twitter)",
        "qr": "",
        "url": ""
      },
      {
        "n": "Snapchat",
        "qr": "",
        "url": ""
      },
      {
        "n": "LinkedIn",
        "qr": "",
        "url": ""
      },
      {
        "n": "WhatsApp Channel",
        "qr": "",
        "url": ""
      },
      {
        "n": "Telegram",
        "qr": "",
        "url": ""
      },
      {
        "n": "Pinterest",
        "qr": "",
        "url": ""
      }
    ],
    "brands": [
      {
        "n": "Silver Metal Industries LLC SP",
        "img": "images/brands/silver-metal-industries-llc-sp.jpg"
      },
      {
        "n": "Jabrul Haq Building Materials LLC",
        "img": "images/brands/jabrul-haq-building-materials-llc.jpg"
      },
      {
        "n": "Muhammad Yar Bldg Mat Tr",
        "img": "images/brands/muhammad-yar-bldg-mat-tr.jpg"
      },
      {
        "n": "Al-Fath Building Materials Trading LLC SP",
        "img": "images/brands/al-fath-building-materials-trading-llc-sp.jpg"
      },
      {
        "n": "Silver Metal Industries (SMI)",
        "img": "images/brands/silver-metal-industries-smi.jpg"
      }
    ]
  },
  "orders": [],
  "cats": [
    "Sandwich Panels",
    "Roofing & Cladding Sheets",
    "Steel Pipes & Sections",
    "Fencing"
  ],
  "products": [
    {
      "id": "p0",
      "name": "GI Pipe",
      "cat": "Steel Pipes & Sections",
      "desc": "GI (Galvanized Iron) pipe is a steel pipe coated with a layer of zinc to protect it from corrosion and rust. Widely used for water supply and many other applications.",
      "price": "",
      "imgs": [
        "images/products/gi-pipe-1.jpg"
      ]
    },
    {
      "id": "p1",
      "name": "Tile Profile Sheet",
      "cat": "Roofing & Cladding Sheets",
      "desc": "Metal sheet profile used for roofing and wall cladding, designed to mimic the appearance of tiles. Available in multiple colours.",
      "price": "",
      "imgs": [
        "images/products/tile-profile-sheet-1.jpg"
      ]
    },
    {
      "id": "p2",
      "name": "Wall Fence",
      "cat": "Fencing",
      "desc": "Temporary hoarding panels / discontinuous corrugated fencing by Silver Metal Industries LLC (The Hafiz Groups).",
      "price": "",
      "imgs": [
        "images/products/wall-fence-1.jpg",
        "images/products/wall-fence-2.jpg",
        "images/products/wall-fence-3.jpg",
        "images/products/wall-fence-4.jpg",
        "images/products/wall-fence-5.jpg",
        "images/products/wall-fence-6.jpg"
      ]
    },
    {
      "id": "p3",
      "name": "Roof Sandwich PU 100mm",
      "cat": "Sandwich Panels",
      "desc": "PU (Polyurethane) sandwich panels are high-performance insulated panels used for roofing, wall cladding and cold storage applications.",
      "price": "",
      "imgs": [
        "images/products/roof-sandwich-pu-100mm-1.jpg"
      ]
    },
    {
      "id": "p4",
      "name": "MS Square Tube",
      "cat": "Steel Pipes & Sections",
      "desc": "MS (Mild Steel) square tubes are hollow structural sections made from low-carbon steel, offering excellent strength and versatility.",
      "price": "",
      "imgs": [
        "images/products/ms-square-tube-1.jpg",
        "images/products/ms-square-tube-2.jpg",
        "images/products/ms-square-tube-3.jpg",
        "images/products/ms-square-tube-4.jpg"
      ]
    },
    {
      "id": "p5",
      "name": "Profile Sheet Single Skin",
      "cat": "Roofing & Cladding Sheets",
      "desc": "Galvanized corrugated steel sheets designed to provide excellent structural strength and weather resistance, coated with zinc for protection.",
      "price": "",
      "imgs": [
        "images/products/profile-sheet-single-skin-1.jpg"
      ]
    },
    {
      "id": "p6",
      "name": "Wall Panel PU 100mm",
      "cat": "Sandwich Panels",
      "desc": "100mm wall panel for constructing walls, offering thermal insulation, fire resistance and structural integrity.",
      "price": "",
      "imgs": [
        "images/products/wall-panel-pu-100mm-1.jpg"
      ]
    },
    {
      "id": "p7",
      "name": "MS Angle",
      "cat": "Steel Pipes & Sections",
      "desc": "Mild steel angle sections for structural and fabrication work.",
      "price": "",
      "imgs": [
        "images/products/ms-angle-1.jpg"
      ]
    },
    {
      "id": "p8",
      "name": "Galvanized GI Concrete Sheet",
      "cat": "Roofing & Cladding Sheets",
      "desc": "Galvanized iron sheet used in concrete construction.",
      "price": "",
      "imgs": [
        "images/products/galvanized-gi-concrete-sheet-1.jpg"
      ]
    },
    {
      "id": "p9",
      "name": "Wall Panel PU 50mm",
      "cat": "Sandwich Panels",
      "desc": "Roof / wall panels available in RAL colours: RAL 5002 Blue, RAL 1014 Light Beige, RAL 9002 Off White, RAL 1001 Beige, RAL 6029 Light Green and more.",
      "price": "",
      "imgs": [
        "images/products/wall-panel-pu-50mm-1.jpg",
        "images/products/wall-panel-pu-50mm-2.jpg"
      ]
    },
    {
      "id": "p10",
      "name": "Roof Sandwich PU 50mm",
      "cat": "Sandwich Panels",
      "desc": "PU (Polyurethane) sandwich panels are high-performance insulated panels used for roofing, wall cladding and cold storage applications.",
      "price": "",
      "imgs": [
        "images/products/roof-sandwich-pu-50mm-1.jpg",
        "images/products/roof-sandwich-pu-50mm-2.jpg"
      ]
    },
    {
      "id": "p11",
      "name": "GI Roof Z Purlins",
      "cat": "Steel Pipes & Sections",
      "desc": "Z (zed) purlins are horizontal beams designed to form the roof and wall joists of a building shell structure.",
      "price": "",
      "imgs": [
        "images/products/gi-roof-z-purlins-1.jpg",
        "images/products/gi-roof-z-purlins-2.jpg",
        "images/products/gi-roof-z-purlins-3.jpg"
      ]
    },
    {
      "id": "p1793516902",
      "name": "Trapezoidal Profile Roofing Panels",
      "cat": "Sandwich Panels",
      "desc": "Trapezoidal profile insulated sandwich panels for roofing and cladding, available in stock.",
      "price": "",
      "imgs": [
        "images/products/trapezoidal-profile-roofing-panels-1.jpg"
      ]
    },
    {
      "id": "p1793516903",
      "name": "Galvanized Round Pipes",
      "cat": "Steel Pipes & Sections",
      "desc": "Galvanized round steel pipes in different sizes, available in stock.",
      "price": "",
      "imgs": [
        "images/products/galvanized-round-pipes-1.jpg"
      ]
    },
    {
      "id": "p1793516904",
      "name": "MS Square Tube (Heavy Section)",
      "cat": "Steel Pipes & Sections",
      "desc": "Heavy section mild steel square tubes for structural and fabrication work.",
      "price": "",
      "imgs": [
        "images/products/ms-square-tube-heavy-section-1.jpg"
      ]
    },
    {
      "id": "p1793516905",
      "name": "MS Rectangular Tube",
      "cat": "Steel Pipes & Sections",
      "desc": "Mild steel rectangular tubes in different sizes for structural and fabrication work.",
      "price": "",
      "imgs": [
        "images/products/ms-rectangular-tube-1.jpg",
        "images/products/ms-rectangular-tube-2.jpg"
      ]
    },
    {
      "id": "p1793516906",
      "name": "MS Square Tube (Medium)",
      "cat": "Steel Pipes & Sections",
      "desc": "Mild steel square tubes, medium section, available in stock.",
      "price": "",
      "imgs": [
        "images/products/ms-square-tube-medium-1.jpg"
      ]
    },
    {
      "id": "p1793516907",
      "name": "MS Square Tube (Stack)",
      "cat": "Steel Pipes & Sections",
      "desc": "Mild steel square tubes in bulk stock for projects and wholesale orders.",
      "price": "",
      "imgs": [
        "images/products/ms-square-tube-stack-1.jpg"
      ]
    },
    {
      "id": "p1793517915",
      "name": "MS I-Beam",
      "cat": "Steel Pipes & Sections",
      "desc": "Mild steel I-beams (H-beams) for structural and construction work, available in stock.",
      "price": "",
      "imgs": [
        "images/products/ms-i-beam-1.jpg",
        "images/products/ms-i-beam-2.jpg",
        "images/products/ms-i-beam-3.jpg"
      ]
    },
    {
      "id": "p1793517917",
      "name": "PU Sandwich Panels (Green)",
      "cat": "Sandwich Panels",
      "desc": "PU sandwich panels with green outer skin for roofing and wall cladding, available in stock.",
      "price": "",
      "imgs": [
        "images/products/pu-sandwich-panels-green-1.jpg",
        "images/products/pu-sandwich-panels-green-2.jpg",
        "images/products/pu-sandwich-panels-green-3.jpg"
      ]
    },
    {
      "id": "p1793517918",
      "name": "PU Sandwich Panels (Grey)",
      "cat": "Sandwich Panels",
      "desc": "Insulated PU sandwich panels in grey finish, ready for dispatch.",
      "price": "",
      "imgs": [
        "images/products/pu-sandwich-panels-grey-1.jpg"
      ]
    },
    {
      "id": "p1793517919",
      "name": "Tile Profile Sandwich Panel (Red)",
      "cat": "Sandwich Panels",
      "desc": "Tile-effect roofing sandwich panels with insulated core, in red colour.",
      "price": "",
      "imgs": [
        "images/products/tile-profile-sandwich-panel-red-1.jpg"
      ]
    }
  ]
};
